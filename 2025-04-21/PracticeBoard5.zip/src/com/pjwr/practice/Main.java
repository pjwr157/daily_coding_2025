package com.pjwr.practice;

public class Main {
	public static void main(String[] args) {

		int score = 85;
		if(score>=90) {
			System.out.println("A");
		}else if(score>=80){
			System.out.println("B");
		}else if(score>=70){
			System.out.println("C");
		}else{
			System.out.println("F");
			
		}
	}
}
