package com.pjwr.practice;

public class Main {
	public static void main(String[] args) {
		
		String gender = "M";
		if(gender.equals("M")) {
			System.out.println("남자입니다");
		}else {
			System.out.println("여자입니다");
		}
	}
}
