package com.pjwr.practice;

public class Main {
	public static void main(String[] args) {

		int num = 15;
		if(num>10) {
			System.out.println("Bigger than 10");
		}else {
			System.out.println("DUNNO");
		}
	}
}
