package com.pjwr.testing;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
    	HashSet<String> hs = new HashSet<>();
    	hs.add("개");
    	hs.add("개");
    	hs.add("사자");
    	hs.add("고양이");
    	hs.add("호랑이");
    	hs.add("토끼");
    	hs.add("늑대");

		
		int size = hs.size();
		
		System.out.println(size);
		
		Iterator<String> it = hs.iterator();
		System.out.println("-while, next() 으로 꺼내기-");
		while(it.hasNext()) {
			String s1 = it.next();
			System.out.println(s1);
		}
    }
}
