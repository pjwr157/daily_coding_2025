package com.pjwr.practice;

public class Main {
	public static void main(String[] args) {
		
		int temp = 8;
		if (temp >= 30) {
		    System.out.println("더워요");
		} else if (temp >= 10) {
		    System.out.println("괜찮은 날씨예요");
		} else {
		    System.out.println("추워요");
		}
	}
}
