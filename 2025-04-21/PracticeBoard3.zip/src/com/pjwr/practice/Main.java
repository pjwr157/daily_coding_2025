package com.pjwr.practice;

public class Main {
	public static void main(String[] args) {

		int score = 72;
		if (score >= 60) {
		    System.out.println("PASS");
		} else {
		    System.out.println("BYEBYE");
		}
	}
}
