package com.pjwr.practice;

public class Main {
	public static void main(String[] args) {
		
		String color = "blue";
		if(color.equals("red")) {
			System.out.println("RED");
		}else if(color.equals("blue")){
			System.out.println("BLUE");
		}else{
			System.out.println("OTHER COLOR");
		}
	}
}
