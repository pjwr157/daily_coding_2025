package com.pjwr.practice;

public class Main {
	public static void main(String[] args) {

		int num = -5;
		if (num < 0) {
		    System.out.println("Negative Desu");
		}else {
			System.out.println("DUNNO");
		}
	}
}
