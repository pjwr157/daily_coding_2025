package com.pjwr.testing;


//싱글톤 Singleton 패턴 적용한 클래스 ex.  
public class Cat {
	int n;
	//2.내 멤버 변수(필드)에 내 클래스형 변수를 추가
//	Cat cat;
	//3.내 멤버 변수(필드)에 내 클래스형 변수를 추가
	//우변에 초기화로 new Cat() 으로 객체 생성자 호출하고 대입하기
//	Cat cat = new Cat();
	//4.내 멤버 변수(필드)에 내 클래스형 변수를 추가
	//우변에 초기화로 new Cat() 으로 객체 생성자 호출하고 대입하기
	//좌변 변수에 static 추가
//	static Cat cat = new Cat();
	
	//5.내 멤버 변수(필드)에 내 클래스형 변수를 추가
	//우변에 초기화로 new Cat() 으로 객체 생성자 호출하고 대입하기
	//좌변 변수에 static 추가
	//근데 이 변수를 private 로 잠궈버림
	private static Cat cat = new Cat();
	
	//1.생성자 함수의 접근제한자를 private 로 함.
	private Cat(){
		
	}
	
	//6. Cat 객체 static 변수를 리턴하는 함수 만들기 
//	Cat getCat() {
//		return cat;
//	}
	
	//7. Cat 객체 static 변수를 리턴하는 함수 만들기 
	static Cat getInstance() {
		return cat;
	}
	
	void x() {
		System.out.println("야옹");
	}
	
	
	
	
}
