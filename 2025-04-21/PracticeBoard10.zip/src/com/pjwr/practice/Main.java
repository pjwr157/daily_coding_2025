package com.pjwr.practice;

public class Main {
	public static void main(String[] args) {
		int hour = 14;
		if (hour >= 6 && hour < 12) {
		    System.out.println("아침입니다");
		} else if (hour >= 12 && hour < 18) {
		    System.out.println("오후입니다");
		} else {
		    System.out.println("저녁입니다");
		}
	}
}
