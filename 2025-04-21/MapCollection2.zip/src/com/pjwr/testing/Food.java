package com.pjwr.testing;

public class Food {
	String name;
	boolean isHot;
	int price;

	public Food(String name, boolean isHot, int price) {
		this.name = name;
		this.isHot = isHot;
		this.price = price;
	}
}