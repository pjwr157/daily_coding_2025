package com.peisia.easyboard;

public class Post {
	int no;
	String title;
	String content;
	String writer;

public Post(String title, String content, String writer, int saveNo) {
	super();
	no = saveNo;
	this.title = title;
	this.content = content;
	this.writer = writer;
	}
}