package com.peisia.easyboard;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Board {
	Scanner sc = new Scanner(System.in);
	ArrayList<Post> ps = new ArrayList<>();
	int saveNo = 0;
	
	void run() {
		xx:while(true) {
			//todo
			//메뉴 선택하게 하기
			System.out.println("crud 1.쓰기 2.읽기 3.리스트 4.수정 5.삭제 e.프로그램 종료");
			String cmd = sc.next();
			switch(cmd) {
			case "1":
				System.out.println("쓰기");
				System.out.println("제목: ");
				String title = sc.next();
				System.out.println("본문: ");
				String content = sc.next();
				System.out.println("작성자: ");
				String writer = sc.next();
				saveNo = saveNo + 1;
				Post p = new Post(title,content,writer,saveNo);
				ps.add(p);
				break;
				
			case "2":
				System.out.println("읽기");
				//todo
				//몇번글을 읽을지 물어보기!
				System.out.println("몇번글을 읽을까요?: ");
				cmd = sc.next();
				
				//해당 글을 찾기
				for (int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
//					int postNo = post.no;
//					String postStringNo = postNo + "";
					String postStringNo = post.no + "";
					if(postStringNo.equals(cmd)) {
						//읽기(출력)
						System.out.println("글번호: "+post.no+" 글 내용: "+post.content+" 작성자: "+post.writer);
					}
				}
				break;
				
			case "3":
				System.out.println("리스트");
				for(int i=0;i<ps.size();i++) {
					String t = ps.get(i).title;
					String c = ps.get(i).content;
					String w = ps.get(i).writer;
					int no = ps.get(i).no;
					System.out.println("글번호: "+no+" 제목: "+t+" 작성자: "+w);
				}
				break;
				
			case "4":
				System.out.println("수정");
				//todo
				//수정 할 글 번호 입력받기
				System.out.println("몇번글을 수정할까요?: ");
				cmd = sc.next();
				//해당 글 가져오기
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					String postStringNo = post.no + "";
					if(postStringNo.equals(cmd)){ //찾았다~
						//바꿀 내용 입력하기
						System.out.println("바꿀내용은?: ");
						post.content = sc.next(); //내용을 기존 번호에 덮어쓰기
					}
				}
				break;
				
			case "5":
				System.out.println("삭제");
				//todo
				//삭제 할 글 번호 입력받기
				System.out.println("몇번글을 지울까요?: ");
				cmd = sc.next();
				//글 리스트에서 삭제할 글 찾기
				int searchNo = 0;
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					String postStringNo = post.no + "";
					if(postStringNo.equals(cmd)) {
						//인덱스 i 를 기억해놓기
						searchNo = i;
					}
				}
				//삭제
				ps.remove(searchNo);
				System.out.println("삭제됨ㅋㅋ");
				break;
			
			case "e":
				System.out.println("프로그램을 종료합니다.");
				break xx;
			}
		}
	}
}
