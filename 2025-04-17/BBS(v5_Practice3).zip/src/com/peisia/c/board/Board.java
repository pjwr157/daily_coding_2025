package com.peisia.c.board;

import java.util.ArrayList;
import java.util.Scanner;

public class Board {
	Scanner sc = new Scanner(System.in);
	ArrayList<Post> posts = new ArrayList<Post>();
	int count = 0;

	void run() {
		xx: while (true) {
			System.out.println("1.쓰기 2.읽기 3.리스트 4.삭제 5.수정 e.종료");
			String cmd = sc.next();
			System.out.println("cmd디버깅체크용도");

			switch (cmd) {
			case "1": // Write
				System.out.println("쓰기");
				System.out.println("제목: ");
				String title = sc.next();
				System.out.println("내용: ");
				sc.nextLine();
				String content = sc.nextLine();
				System.out.println("작가: ");
				String writer = sc.next();
				count++;
				Post p = new Post(count, title, content, writer);
				posts.add(p);
				break;

			case "2": // Read
				System.out.println("읽기");
				System.out.println("읽으실 글 번호를 입력해주세요: ");
				int selectNo = sc.nextInt();
				System.out.println("Case2 Debug Point");
				for (Post p1 : posts) {
					if (p1.no == selectNo) {
						p1.infoForRead();
					}
				}
				break;

			case "3": // List
				System.out.println("==========리스트==========");
				for (Post p1 : posts) {
					p1.info();
				}
				break;

			case "4": // Delete
				System.out.println("삭제");
				System.out.println("Case4 Debug Point");
				int selectDeleteNo = sc.nextInt();
				System.out.println("디버깅확인");
				int searchIndex = 0;
				for (int i = 0; i < posts.size(); i++) {
					Post pp = posts.get(i);
					if (pp.no == selectDeleteNo) {
						System.out.println("There you are");
						searchIndex = i;
						break;
					}
				}
				posts.remove(searchIndex);
				break;

			case "5": // update
				System.out.println("==========수정==========");
				System.out.println("수정하실 글 번호를 입력해주세요: ");
				int selectNo1 = sc.nextInt();
				for (Post p1 : posts) {
					if (p1.no == selectNo1) {
						System.out.println("====================");
						System.out.println(p1.content);
						System.out.println("====================");
						System.out.println("바꿀 내용 입력해라");
						String newContent = sc.next();
						p1.content = newContent;
						break;
					}
				}
				break;

			case "e":
				System.out.println("프로그램종료다옹");
				break xx;
			default:
				System.out.println("똑바로쓰라");
				break;
			}
		}
	}
}