package com.peisia.c.board;

public class Post {
	int no = 0;
	String title;
	String content;
	String writer;
	
	public Post(int no, String title, String content, String writer) {
		this.no = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
	}
	
	public void info() {
		String s = String.format("PageNo.: %s, Title: %s, Writer: %s", no, title, writer);
		System.out.println(s);
	}
	
	public void infoRead() {
		String s = String.format("PageNo.: %s, Title: %s, Writer: %s", no, title, writer);
		System.out.println("===============================================================");
		System.out.println(s);
		System.out.println("===============================================================");
		System.out.println(content);
		System.out.println("===============================================================");
	}
}
