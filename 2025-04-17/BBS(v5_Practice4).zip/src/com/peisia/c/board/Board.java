package com.peisia.c.board;

import java.util.ArrayList;
import java.util.Scanner;

public class Board {
	Scanner sc = new Scanner(System.in);
	ArrayList<Post> ps = new ArrayList<>();
	int no = 0;
	
	void run() {
		xx: while(true) {
			//todo
			//Select Menu
			System.out.println("crlud 1.Create 2.Read 3.List 4.Update 5.Delete e.Shutdown");
			String cmd = sc.next();
			switch(cmd) {
			case "1": //Create
				System.out.println("You picked 1; Create!");
				System.out.println("Title?: ");
				String title = sc.next();
				System.out.println(" Content?: ");
				String content = sc.next();
				System.out.println(" Writer?: ");
				String writer = sc.next();
				no++;
				Post p = new Post(no,content,writer,title);
				ps.add(p);
				break;
				
			case "2": //Read
				System.out.println("You picked 2; Read!");
				//todo
				//Ask what No. to read
				System.out.println("Pick a No. to Read!: ");
				cmd = sc.next();
				//Find the designated No.
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					String postStringNo = post.no + "";
					if(cmd.equals(postStringNo)) { //Found!
						//Read(Output)
						System.out.println("PageNo.: "+post.no+" Title: "+post.title+" Content: "+post.content+" Writer: "+post.writer);
					}
				}
				break;
				
			case "3": //List
				System.out.println("You picked 3; List!");
				for(int i=0;i<ps.size();i++) {
					String t = ps.get(i).title;
//					String c = ps.get(i).content;
					String w = ps.get(i).writer;
					int no = ps.get(i).no;
					System.out.println("============================================");
					System.out.println(" PageNo.: "+no+" Title: "+t+" Writer: "+w);
					System.out.println("============================================");
				}
				break;
				
			case "4": //Update
				System.out.println("You picked 4; Update!");
				//todo
				//Ask what No. to update
				System.out.println("Pick a No. to Update!: ");
				cmd = sc.next();
				//Find the designated No.
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					String postStringNo = post.no + "";
					if(postStringNo.equals(cmd)) {  //Found!
						//Input Update Context
						System.out.println("Type the Update!: ");
						post.content = sc.next(); //Overwrite the Update to the original No.
					}
				}
				break;
				
			case "5": //Delete
				System.out.println();
				//todo
				//Ask what No. to delete
				//Find the No. to delete among the List
				//Remember index i
				//DELETE
				break;
				
			case "e": //Shutdown
				System.out.println("Shutting Down Program");
				break xx;
			}
			
		}
	}
}
