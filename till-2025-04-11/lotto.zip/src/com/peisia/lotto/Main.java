package com.peisia.lotto;

public class Main {

	public static void main(String[] args) {
		Lotto lotto = new Lotto();
		lotto.run();
	}

}
