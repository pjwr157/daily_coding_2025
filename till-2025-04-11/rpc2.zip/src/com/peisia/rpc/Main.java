package com.peisia.rpc;

public class Main {
	public static void main(String[] args) {
		Rps rps = new Rps();
		rps.run();
	}
}