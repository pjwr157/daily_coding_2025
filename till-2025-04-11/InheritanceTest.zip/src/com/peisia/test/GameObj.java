package com.peisia.test;

public class GameObj {
	String name;
	
	void info() {
		System.out.println("이름:"+name);
	}
}
