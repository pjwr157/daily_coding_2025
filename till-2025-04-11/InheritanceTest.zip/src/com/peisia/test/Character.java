package com.peisia.test;

public class Character extends GameObj{
//	String name;
	int hp;
	int attack;
	
}
