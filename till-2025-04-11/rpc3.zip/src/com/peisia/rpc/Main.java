package com.peisia.rpc;

public class Main {
	public static void main(String[] args) {
		Rps r = new Rps();
		r.run();
	}
}
