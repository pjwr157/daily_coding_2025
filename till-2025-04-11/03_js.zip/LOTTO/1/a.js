var r1 = Math.floor(Math.random() * 45)+1;
var r2 = Math.floor(Math.random() * 45)+1;
var r3 = Math.floor(Math.random() * 45)+1;
var r4 = Math.floor(Math.random() * 45)+1;
var r5 = Math.floor(Math.random() * 45)+1;
var r6 = Math.floor(Math.random() * 45)+1;

document.write(r1);
br()
document.write(r2);
br()
document.write(r3);
br()
document.write(r4);
br()
document.write(r5);
br()
document.write(r6);
br()