function br(){
    document.write("<br>");
}
function log(s){
    console.log(s);
}

function hr(){
    document.write("<hr>");
}

function dw(s){
    document.write(s);
}

function resultTextAdd(s){
    resultText = resultText + s;
}

function add(a,b){
    var x = a+b;
    return x;
}
