
// var s = prompt("값을 입력하세요 :");
// switch(s){
//     case "1":
//         alert("1임");
//         break;
//     case "2":
//         alert("2임");
//         break;
//     case "3":
//         alert("3임");
//         break;
//     default:
//         alert("1,2,3 아님")        ;

// }

function dw(str){
    alert(str);
}

var a = prompt("write: ")
if (a == 1){
    dw("1");
} else if (a==2){
    dw("2");
} else if (a==3){
    dw("3");
} else{
    dw("nothing");
}