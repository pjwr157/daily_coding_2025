for(var i = 1; i<=10; i+=1){
    document.write(i + "<hr>")
}