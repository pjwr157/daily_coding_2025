// 문3	반복문	고양이<hr>	를 5번 출력하세요
// 초기값 ,  조건식 , 증가식
//        true / false
for(var x=1 ; x < 6 ; x = x + 1 )
    {
        document.write("고양이<hr>");
        document.write("고양이<hr>");
        document.write("고양이<hr>");
    }