package com.pjwr.testing;

public class Main {
	public static void main(String[] args) {
		
		String[] fruits = {"Apple", "Banana", "Cherry"};
		for(int i=1;i<=fruits.length;i++) {
			System.out.println(i+": "+fruits[i-1]);
		}

		String[] fruitss = {"Apple", "Banana", "Cherry"};

		for (int i = 0; i < fruitss.length; i++) {
		    System.out.println(i + ": " + fruitss[i]); // 인덱스 + 값 출력
		}

		
	}
}
