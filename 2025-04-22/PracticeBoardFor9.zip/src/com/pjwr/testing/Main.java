package com.pjwr.testing;

public class Main {
	public static void main(String[] args) {
		
		for (int i = 1; i <= 100; i++) {
		    if (i % 3 == 0 && i % 5 == 0) {
		        System.out.println("FizzBuzz"); // 3과 5의 공배수
		    } else if (i % 3 == 0) {
		        System.out.println("Fizz"); // 3의 배수
		    } else if (i % 5 == 0) {
		        System.out.println("Buzz"); // 5의 배수
		    } else {
		        System.out.println(i); // 그 외는 숫자 그대로
		    }
		}

	}
}
