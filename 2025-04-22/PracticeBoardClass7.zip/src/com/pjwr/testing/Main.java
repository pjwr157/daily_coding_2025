//package com.pjwr.testing;
//
//public class Main {
//    public static void main(String[] args) {
//        Student[] students = {
//            new Student("철수", 90),
//            new Student("영희", 85),
//            new Student("민수", 78)
//        };
//
//        for (Student s : students) {
//            s.printInfo();
//        }
//    }
//}
package com.pjwr.testing;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // ArrayList 사용
        ArrayList<Student> students = new ArrayList<>();

        students.add(new Student("철수", 90));
        students.add(new Student("영희", 85));
        students.add(new Student("민수", 78));

        for (Student s : students) {
            s.printInfo();
        }
    }
}