package com.pjwr.testing;

//public class main {
//	public static void main(String[] args) {
//		String name = "홍길동";
//		int age = 20;
//		void introduce() {  //매서드 안에 매서드 선언 안됨
//			System.out.println("안녕하세요, 저는 "+name+"이고, 나이는 "+age+"살입니다.");
//		}
//	}
//}
public class Person {
    String name;
    int age;

    void introduce() {
        System.out.println("안녕하세요, 저는 " + name + "이고, 나이는 " + age + "살입니다.");
    }
}