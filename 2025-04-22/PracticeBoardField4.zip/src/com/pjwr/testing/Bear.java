package com.pjwr.testing;
public class Bear {						
	int age; // 전역 변수 (초기화 안 함)					
						
	void showAge() {					
		System.out.println("곰돌이 나이: " + age);				
	}					
						
	public static void main(String[] args) {					
		Bear b = new Bear();				
		b.showAge();				
	}					
}						