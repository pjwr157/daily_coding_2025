package com.pjwr.testing;

public class Main {
	public static void main(String[] args) {
		for(int i=1;i<=20;i++) {
			if(i%3==0) {
				System.out.println(i);
			}else {
				System.out.println("PASS");
			}
		}
	}
}
