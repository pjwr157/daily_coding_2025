package com.pjwr.testing;

public class Main {

	public static void main(String[] args) {

		Calculator x = new Calculator();
		System.out.println(x.add(10, 5));
	}
}
