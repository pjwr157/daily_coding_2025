package com.pjwr.testing;

public class Main {
	public static void main(String[] args) {
		
		String a = "hello";			
		String b = "hello";			
		System.out.println(a == b); // true			
		
	}
}
