package com.pjwr.testing;

public class Main {
	public static void main(String[] args) {
		
		String saved = "peisia";				
		String input = new String("peisia");				
		System.out.println(input.equals(saved)); // true				
		
	}
}
