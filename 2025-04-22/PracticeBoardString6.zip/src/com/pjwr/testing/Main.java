package com.pjwr.testing;

public class Main {
	public static void main(String[] args) {
		
		String s1 = new String("hello").intern();				
		String s2 = "hello";				
		System.out.println(s1 == s2); // true				
		
	}
}
