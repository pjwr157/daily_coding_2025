package com.pjwr.testing;
public class Dog {							
	String name = "복실이"; // 전역(멤버) 변수						
							
	void bark() {						
		String sound = "멍멍"; // 지역 변수					
		System.out.println(name + "가 " + sound + " 짖어요!");					
	}						
							
	public static void main(String[] args) {						
		Dog d = new Dog();					
		d.bark();					
	}						
}							