//package com.pjwr.testing;
//
//public class Main {
//    public static void main(String[] args) {
//        Student[] students = {
//            new Student("철수", 90),
//            new Student("영희", 85),
//            new Student("민수", 78)
//        };
//
//        for (Student s : students) {
//            s.printInfo();
//        }
//    }
//}
package com.pjwr.testing;

public class Main {
    public static void main(String[] args) {
        Student[] students = {
            new Student("철수", 90),
            new Student("영희", 85),
            new Student("민수", 78)
        };

        Student top = students[0]; // 가장 높은 점수를 가진 학생 저장용

        for (int i = 1; i < students.length; i++) {
            if (students[i].score > top.score) {
                top = students[i];
            }
        }

        System.out.println("최고 점수 학생: " + top.name);
    }
}
