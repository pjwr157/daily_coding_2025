package com.pjwr.testing;

public class Main {
    public static void main(String[] args) {
		Person hong = new Person();
		hong.name = "홍길동";
        hong.age = 20;
		hong.introduce();
	}
}