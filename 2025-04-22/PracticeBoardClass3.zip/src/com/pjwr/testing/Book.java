package com.pjwr.testing;

public class Book {
    String title;
    String author;

    // 생성자 정의
    Book(String javaNoJyouseki, String namGoogSung) {
        title = javaNoJyouseki;
        author = namGoogSung;
    }

    void printInfo() {
        System.out.println("책 제목: " + title + ", 저자: " + author);
    }
}
