package com.pjwr.testing;
public class Cat {						
	void meow() {					
		String sound = "야옹";				
		// sound = "야옹"; ← 이 줄이 없으면 어떻게 될까?				
		System.out.println(sound);				
	}					
						
	public static void main(String[] args) {					
		Cat c = new Cat();				
		c.meow();				
	}					
}						