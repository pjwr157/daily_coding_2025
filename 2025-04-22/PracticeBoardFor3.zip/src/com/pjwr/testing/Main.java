package com.pjwr.testing;

public class Main {
	public static void main(String[] args) {
		for(int i=1;i<=10;i++) {
			if(i==5) {
				System.out.println(i+"입니다");
			}else {
				System.out.println(i);
			}
		}
	}
}
