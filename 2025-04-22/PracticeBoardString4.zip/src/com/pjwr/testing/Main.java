package com.pjwr.testing;

public class Main {
	public static void main(String[] args) {

		String s1 = "java";									
		String s2 = "java";									
		System.out.println(System.identityHashCode(s1) == System.identityHashCode(s2)); // true									
		
	}
}
