package com.pjwr.testing;
public class Rabbit {								
	String name = "토실이"; // 멤버 변수							
								
	void introduce() {							
		String name = "복슬이"; // 지역 변수						
		System.out.println("안녕! 나는 " + name + "야");         // (1)						
		System.out.println("진짜 이름은 " + this.name + "야");  // (2)						
	}							
								
	public static void main(String[] args) {							
		Rabbit r = new Rabbit();						
		r.introduce();						
	}							
}								