package com.pjwr.testing;
public class Chick {					
	void tweet() {				
	String sound = "무야호~!";				
	System.out.println("병아리: " + sound + "!");				
}					
					
public static void main(String[] args) {					
	Chick c = new Chick();				
	c.tweet();				
	}				
}					