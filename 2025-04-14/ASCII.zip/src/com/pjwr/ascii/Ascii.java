0	NUL	Null	64	@	At symbol
1	SOH	Start of Header	65	A	대문자 A
2	STX	Start of Text	66	B	대문자 B
3	ETX	End of Text	67	C	대문자 C
4	EOT	End of Transm.	68	D	대문자 D
5	ENQ	Enquiry	69	E	대문자 E
6	ACK	Acknowledge	70	F	대문자 F
7	BEL	Bell	71	G	대문자 G
8	BS	Backspace	72	H	대문자 H
9	TAB	Horizontal Tab	73	I	대문자 I
10	LF	Line Feed	74	J	대문자 J
11	VT	Vertical Tab	75	K	대문자 K
12	FF	Form Feed	76	L	대문자 L
13	CR	Carriage Return	77	M	대문자 M
14	SO	Shift Out	78	N	대문자 N
15	SI	Shift In	79	O	대문자 O
16	DLE	Data Link Escape	80	P	대문자 P
17	DC1	Device Control 1	81	Q	대문자 Q
18	DC2	Device Control 2	82	R	대문자 R
19	DC3	Device Control 3	83	S	대문자 S
20	DC4	Device Control 4	84	T	대문자 T
21	NAK	Negative ACK	85	U	대문자 U
22	SYN	Synchronous Idle	86	V	대문자 V
23	ETB	End of Block	87	W	대문자 W
24	CAN	Cancel	88	X	대문자 X
25	EM	End of Medium	89	Y	대문자 Y
26	SUB	Substitute	90	Z	대문자 Z
27	ESC	Escape	91	[	Left bracket
28	FS	File Separator	92	\	Backslash
29	GS	Group Separator	93	]	Right bracket
30	RS	Record Separator	94	^	Caret
31	US	Unit Separator	95	_	Underscore
32	(공백)	Space	96	`	Backtick

48	0	숫자 0	97	a	소문자 a
49	1	숫자 1	98	b	소문자 b
50	2	숫자 2	99	c	소문자 c
51	3	숫자 3	100	d	소문자 d
52	4	숫자 4	101	e	소문자 e
53	5	숫자 5	102	f	소문자 f
54	6	숫자 6	103	g	소문자 g
55	7	숫자 7	104	h	소문자 h
56	8	숫자 8	105	i	소문자 i
57	9	숫자 9	106	j	소문자 j
58	:	콜론	107	k	소문자 k
59	;	세미콜론	108	l	소문자 l
60	<	작다	109	m	소문자 m
61	=	같다	110	n	소문자 n
62	>	크다	111	o	소문자 o
63	?	물음표	112	p	소문자 p
64	@	골뱅이	113	q	소문자 q
...		...
122	z	소문자 z			
127	DEL	Delete 키