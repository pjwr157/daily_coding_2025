package com.peisia.c.board;

import java.util.ArrayList;
import java.util.Scanner;

public class Board {
	Scanner sc = new Scanner(System.in);
	ArrayList<Post> ps = new ArrayList<>();
	int no = 0;
	
	void run() {
		xx: while(true) {
			//todo
			//Select Menu
			System.out.println("crlud 1.Create 2.Read 3.List 4.Update 5.Delete e.Shutdown");
			String cmd = sc.nextLine();
			switch(cmd) {
			case "1": //Create
				System.out.println("You picked 1; Create!");
				System.out.println("Title?: ");
				String title = sc.nextLine();
				System.out.println(" Content?: ");
				String content = sc.nextLine();
				System.out.println(" Writer?: ");
				String writer = sc.nextLine();
				no++;
				Post p = new Post(no,title,content,writer);
				ps.add(p);
				break;
				
			case "2": //Read
				System.out.println("You picked 2; Read!");
				//todo
				//Ask what No. to read
				System.out.println("Pick a No. to Read!: ");
				cmd = sc.nextLine();
				//Find the designated No.
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					String postStringNo = post.no + "";
					if(cmd.equals(postStringNo)) { //Found!
						//Read(Output)
						System.out.println("PageNo.: "+post.no+" Title: "+post.title+" Content: "+post.content+" Writer: "+post.writer);
					}
				}
				break;
				
			case "3": //List
				System.out.println("You picked 3; List!");
				for(int i=0;i<ps.size();i++) {
					String t = ps.get(i).title;
//					String c = ps.get(i).content;
					String w = ps.get(i).writer;
					int no = ps.get(i).no;
					System.out.println("============================================");
					System.out.println(" PageNo.: "+no+" Title: "+t+" Writer: "+w);
					System.out.println("============================================");
				}
				break;
				
			case "4": //Update
				System.out.println("You picked 4; Update!");
				//todo
				//Ask what No. to update
				System.out.println("Pick a No. to Update!: ");
				cmd = sc.nextLine();
				//Find the designated No.
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					String postStringNo = post.no + "";
					if(postStringNo.equals(cmd)) {  //Found!
						//Input Update Context
						System.out.println("Current Content: "+post.content);
						System.out.println("Type the Update!: ");
						post.content = sc.nextLine(); //Overwrite the Update to the original No.
						System.out.println("Update Complete!");
					}
				}
				break;
				
			case "5": //Delete
				System.out.println("You picked 5; Delete!");
				//todo
				//Ask what No. to delete
				System.out.println("Pick a No. to Delete!: ");
				cmd = sc.nextLine();
				//Find the No. to delete among the List
				int searchNo = 0;
				for(int i=0;i<ps.size();i++) {
					Post post = ps.get(i);
					String postStringNo = post.no + "";
					if(postStringNo.equals(cmd)) {
						//Remember index i
						searchNo = i;
					}
				}
				//DELETE
				ps.remove(searchNo);
				System.out.println("EXTERMINATED");
				break;
				
			case "e": //Shutdown
				System.out.println("Shutting Down Program");
				break xx;
				
			default:
				System.out.println("Try Again.");
			}
			
		}
	}
}
