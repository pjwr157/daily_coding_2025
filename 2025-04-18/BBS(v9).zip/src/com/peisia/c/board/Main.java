package com.peisia.c.board;

public class Main {
	public static void main(String[] args) {
//		Board board = new Board();
		// 디자인 패턴 - 싱글톤으로 된 클래스의 객체를 얻어오기 위해 Board.getInstance() 호출.
		// getInstance() 이 함수이름이 싱글톤 객체 얻어내는 함수 이름 국룰임.
		Board board = Board.getInstance();	
		
		board.run();
	}
}
