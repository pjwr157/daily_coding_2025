package com.peisia.c.board;

public class Cat {
	public int age;
//	@Override
//	public String toString() {
//		// TODO Auto-generated method stub
//		return "냐옹";
//	}
}
