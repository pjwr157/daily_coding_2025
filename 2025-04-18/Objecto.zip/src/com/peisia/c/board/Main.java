package com.peisia.c.board;

public class Main {  //extends Object (숨어져있음)(자바의 모든 클래쓰는 Object를 상속받음 / 최고의 조상)
	public static void main(String[] args) {
		
		Object o = new Object();  //모든 클래쓰들의 조상(상속의 아버지)(단군할아버지..?)
		Cat cat = new Cat();
		String s = cat.toString();
		System.out.println(s);
		System.out.println(cat);
	}
}
