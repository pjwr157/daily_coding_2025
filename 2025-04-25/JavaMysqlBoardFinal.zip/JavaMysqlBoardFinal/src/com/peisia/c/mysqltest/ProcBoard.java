package com.peisia.c.mysqltest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProcBoard { // (Final Version by pjwr157)
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	Scanner sc = new Scanner(System.in);

	void run() {
		Display.showTitle();
		dbInit();
		loop: while (true) {
			dbPostCount();
			Display.showMainMenu();
			System.out.println("Enter Command: ");
			String cmd = sc.next();
			switch (cmd) {
			case "1":
				System.out.println("==========================================");
				System.out.println("================== List ==================");
				System.out.println("==========================================");
				System.out.println(" PostNo. / PostTitle / Username / PostTime ");
				try {
					result = st.executeQuery("select * from board");
					while (result.next()) {
						String no = result.getString("b_no");
						String title = result.getString("b_title");
						String id = result.getString("b_id");
						String datetime = result.getString("b_datetime");
						System.out.println(no + " " + title + " " + id + " " + datetime);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "2":
				System.out.println("Type the PostNo. to Read:");
				String readNo = sc.next();
				try {
					result = st.executeQuery("select * from board where b_no =" + readNo);
					result.next();
					String title = result.getString("b_title");
					String content = result.getString("b_text");
					System.out.println("Post Title: " + title);
					System.out.println("Post Content: " + content);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "3":
				sc.nextLine();
				System.out.println("Type the title:");
				String title = sc.nextLine();
				System.out.println("Type the content:");
				String content = sc.nextLine();
				System.out.println("Type the username:");
				String id = sc.next();
				try {
					st.executeUpdate("insert into board (b_title,b_id,b_datetime,b_text,b_hit)" + " values ('" + title
							+ "','" + id + "',now(),'" + content + "',0)");
					System.out.println("Posted");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "4":
				System.out.println("Type the PostNo. to Delete:");
				String delNo = sc.next();
				dbExecuteUpdate("delete from board where b_no=" + delNo);
				break;
			case "5":
				System.out.println("Type the PostNo. to Update:");
				String editNo = sc.next();
				System.out.println("Type the title:");
				sc.nextLine();
				String edTitle = sc.nextLine();
				System.out.println("Type the username:");
				String edId = sc.next();
				System.out.println("Type the content:");
				sc.nextLine();
				String edContent = sc.nextLine();

				dbExecuteUpdate("update board set b_title='" + edTitle + "',b_id='" + edId
						+ "',b_datetime=now(),b_text='" + edContent + "' where b_no=" + editNo);
				break;
			case "0":
				break;
			case "e":
				System.out.println("Shutdown");
				break loop;
			default:
				System.out.println("😓😓😓😓😓 Try again 😓😓😓😓😓");
			}
		}
	}

	private void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/BoardTest", "root", "root");
			st = con.createStatement();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("Rows affected:" + resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void dbPostCount() {
		try {
			result = st.executeQuery("select count(*) from board");
			result.next();
			String count = result.getString("count(*)");
			System.out.println("Total posts: " + count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
