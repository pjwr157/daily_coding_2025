package com.peisia.c.mysqltest;

public class Main { 							// (Final Version by pjwr157)
	public static void main(String[] args) {
		ProcBoard procBoard = new ProcBoard();
		procBoard.run();
	}
}