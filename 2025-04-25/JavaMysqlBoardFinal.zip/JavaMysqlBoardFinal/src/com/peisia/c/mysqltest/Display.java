package com.peisia.c.mysqltest;

public class Display {
	static private String TITLE_BAR = "🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈";
	static private String TITLE = "🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈     Notice Board     🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈";

	static private String MAIN_MENU_BAR = "🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰🟰";
	static private String MAIN_MENU = "[1]List [2]Read [3]Write [4]Delete [5]Update [0]Admin [e]Shutdown";

	static public void showTitle() {
		System.out.println(TITLE_BAR);
		System.out.println(TITLE);
		System.out.println(TITLE_BAR);
	}

	static public void showMainMenu() {
		System.out.println(MAIN_MENU_BAR);
		System.out.println(MAIN_MENU);
		System.out.println(MAIN_MENU_BAR);

	}
}
