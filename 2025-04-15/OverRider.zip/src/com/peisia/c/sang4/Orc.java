package com.peisia.c.sang4;

import com.peisia.c.util.So;
import com.peisia.c.util.Color;

public class Orc extends Monster{

	@Override
	void attack(Player p) {
		attack = 5;
		So.ln(Color.GREEN + String.format("몽둥이로 %s에게 피해를 %d 줌",p.name,attack) + Color.EXIT);
	}
	
}
