package com.peisia.c.sang4;

public class Player {
	int hp;
	String name;
	public Player(String name, int hp) {
		this.hp = hp;
		this.name = name;
	}
	
}
